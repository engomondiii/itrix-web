# itriX Web Fix v4.0.5 — client page auto-updates to the AI version (no reload)

## What it does
The /c/[token] page still renders INSTANTLY from the (deterministic) server payload, then
silently polls in the background and swaps in the AI-enriched version the moment it's
ready — no manual reload.

## Files
- `src/app/api/client-page/[token]/route.ts` — passes `usedAi` through in the normalized
  payload.
- `src/types/client.types.ts` — adds optional `usedAi` to `ClientPage`.
- `src/components/client-page/ClientPageLive.tsx` — NEW. Client wrapper: renders the shell
  immediately, polls `/api/client-page/{token}` every 3s until `usedAi` flips true (max
  90s), swaps in the enriched page once, then stops. Silent — no flicker/spinner; if
  enrichment never lands, the deterministic page remains.
- `src/app/c/[token]/page.tsx` — uses `ClientPageLive` instead of `ClientPageShell`.

## Requires
The backend v4.0.5 fix (exposes `usedAi`). Deploy both.

## Apply
```bash
cd /path/to/itrix-web
unzip -o itrix-web-fix.zip -d /tmp/webfix
bash /tmp/webfix/web_fix/APPLY_WEB_FIX.sh
```
Rebuild/redeploy.

## Verified
- `tsc --noEmit` clean across the project.
- Detection path proven: payload `usedAi` goes false→true when the background build
  completes; the poller swaps on that transition.
