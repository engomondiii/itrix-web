#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST_ROOT="$(pwd)"
[[ -f "$DEST_ROOT/package.json" ]] || { echo "ERROR: run from itrix-web root (has package.json)."; exit 1; }
STAMP="$(date +%Y%m%d%H%M%S)"
FILES=(
  "src/app/api/client-page/[token]/route.ts"
  "src/types/client.types.ts"
  "src/components/client-page/ClientPageLive.tsx"
  "src/app/c/[token]/page.tsx"
)
echo "itriX web fix (v4.0.5 — client page auto-update) → ${#FILES[@]} file(s) into: $DEST_ROOT"
for rel in "${FILES[@]}"; do
  src="$SRC_DIR/$rel"; dest="$DEST_ROOT/$rel"
  [[ -f "$src" ]] || { echo "  ! missing $rel"; continue; }
  mkdir -p "$(dirname "$dest")"
  [[ -f "$dest" ]] && { cp -p "$dest" "$dest.bak-$STAMP"; echo "  • backed up  $rel"; }
  cp -f "$src" "$dest"; echo "  ✓ applied    $rel"
done
echo "Done. Rebuild/redeploy (next build)."
