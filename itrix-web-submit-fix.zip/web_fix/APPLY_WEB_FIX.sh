#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST_ROOT="$(pwd)"
if [[ ! -f "$DEST_ROOT/package.json" ]]; then
  echo "ERROR: run this from the itrix-web root (the folder with package.json)." >&2
  exit 1
fi
STAMP="$(date +%Y%m%d%H%M%S)"
FILES=( "src/app/api/review/submit/route.ts" )
echo "itriX web fix (v4.0.3) → applying ${#FILES[@]} file(s) into: $DEST_ROOT"
for rel in "${FILES[@]}"; do
  src="$SRC_DIR/$rel"; dest="$DEST_ROOT/$rel"
  [[ -f "$src" ]] || { echo "  ! missing $rel"; continue; }
  mkdir -p "$(dirname "$dest")"
  [[ -f "$dest" ]] && { cp -p "$dest" "$dest.bak-$STAMP"; echo "  • backed up  $rel"; }
  cp -f "$src" "$dest"; echo "  ✓ applied    $rel"
done
echo "Done. Rebuild/redeploy (next build)."
