# Requires -Version 5.1
# ===========================================================================
#  itriX Surface 1 - fix ERR_TOO_MANY_REDIRECTS on /workspace
#
#  Run from the ROOT of the itrix-web repository:
#
#      Expand-Archive .\itrix-web-redirect-fix-v1.zip -DestinationPath . -Force
#      powershell -ExecutionPolicy Bypass -File .\itrix-web-redirect-fix-v1\INSTALL.ps1
#
#  One modified file. No dependency change, no .env change, nothing deleted.
#
#  -LiteralPath on every file cmdlet; path strings via .NET System.IO;
#  Test-Path verification after each copy; ASCII only.
# ===========================================================================

$ErrorActionPreference = 'Stop'

$PackageName = 'itrix-web-redirect-fix-v1'

function ParentOf([string]$p) { return [System.IO.Path]::GetDirectoryName($p) }
function EnsureDir([string]$d) {
    if ($d -and -not [System.IO.Directory]::Exists($d)) {
        [System.IO.Directory]::CreateDirectory($d) | Out-Null
    }
}

if (-not (Test-Path -LiteralPath 'package.json')) {
    Write-Host "ABORT: package.json not found. Run this from the itrix-web root." -ForegroundColor Red
    exit 1
}
if (-not (Test-Path -LiteralPath 'src\middleware.ts')) {
    Write-Host "ABORT: src\middleware.ts not found - this is not the itrix-web root." -ForegroundColor Red
    exit 1
}

$payloadRoot = Join-Path (Get-Location) "$PackageName\payload"
if (-not (Test-Path -LiteralPath $payloadRoot)) {
    Write-Host "ABORT: payload folder not found at $payloadRoot" -ForegroundColor Red
    exit 1
}

$stamp     = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupDir = Join-Path (Get-Location) ".web-redirect-fix-backup-$stamp"

Write-Host ''
Write-Host 'itriX Surface 1 - fix ERR_TOO_MANY_REDIRECTS on /workspace' -ForegroundColor Cyan
Write-Host ('-' * 70)

$files = Get-ChildItem -LiteralPath $payloadRoot -Recurse -File
foreach ($f in $files) {
    $rel  = $f.FullName.Substring($payloadRoot.Length).TrimStart('\', '/')
    $dest = Join-Path (Get-Location) $rel

    if (Test-Path -LiteralPath $dest) {
        $bak = Join-Path $backupDir $rel
        EnsureDir (ParentOf $bak)
        Copy-Item -LiteralPath $dest -Destination $bak -Force
        $tag = 'MOD'
    } else {
        $tag = 'ADD'
    }

    EnsureDir (ParentOf $dest)
    Copy-Item -LiteralPath $f.FullName -Destination $dest -Force

    if (-not (Test-Path -LiteralPath $dest)) {
        Write-Host "ABORT: copy verification FAILED for $rel" -ForegroundColor Red
        exit 1
    }
    Write-Host ("  {0}  {1}" -f $tag, $rel)
}

Write-Host ('-' * 70)
Write-Host ("Installed {0} file(s), verified on disk." -f $files.Count) -ForegroundColor Green
Write-Host ("Backup: {0}" -f $backupDir)

$gitignore = Join-Path (Get-Location) '.gitignore'
$patterns  = @("$PackageName/", '.web-redirect-fix-backup-*')
if (Test-Path -LiteralPath $gitignore) {
    $existing = Get-Content -LiteralPath $gitignore
    $toAdd = @()
    foreach ($pat in $patterns) { if ($existing -notcontains $pat) { $toAdd += $pat } }
    if ($toAdd.Count -gt 0) {
        Add-Content -LiteralPath $gitignore -Value ''
        Add-Content -LiteralPath $gitignore -Value "# $PackageName"
        foreach ($pat in $toAdd) { Add-Content -LiteralPath $gitignore -Value $pat }
        Write-Host ("Added {0} pattern(s) to .gitignore" -f $toAdd.Count)
    }
}

Write-Host ''
Write-Host 'NEXT STEPS' -ForegroundColor Yellow
Write-Host '  1. npm run build     (expect 116 routes, 0 TypeScript errors)'
Write-Host '  2. Commit and push. Railway redeploys itrix-web.'
Write-Host '  3. Sign in. /workspace now renders instead of looping.'
Write-Host ''
Write-Host 'Clear cookies for itrix-web-production.up.railway.app before retrying:'
Write-Host 'Chrome may have cached the 307 chain.'
Write-Host ''
