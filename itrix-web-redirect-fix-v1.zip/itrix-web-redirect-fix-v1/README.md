# itrix-web — fix `ERR_TOO_MANY_REDIRECTS` on `/workspace`

One modified file: `src/middleware.ts`.

## Install

```powershell
Expand-Archive .\itrix-web-redirect-fix-v1.zip -DestinationPath . -Force
powershell -ExecutionPolicy Bypass -File .\itrix-web-redirect-fix-v1\INSTALL.ps1
```

## The bug

`middleware.ts` had a convenience redirect sending a bare `/workspace` to the
"state-appropriate sub-route", chosen from a cookie hint:

```ts
if (pathname === '/workspace' || pathname === '/workspace/') {
  const hint = req.cookies.get(STATE_HINT_COOKIE)?.value ?? '';
  const url = req.nextUrl.clone();
  url.pathname = STATE_ROUTE[hint] ?? '/workspace';
  return NextResponse.redirect(url);      // <-- unconditional
}
```

**Every value in `STATE_ROUTE` except `poc` is `'/workspace'`** — and so is the
`?? '/workspace'` fallback covering a missing, empty or unrecognised cookie. So the
common case redirected `/workspace` to `/workspace`:

| hint | target | result |
|---|---|---|
| *(none)* | `/workspace` | infinite loop |
| `nda` | `/workspace` | infinite loop |
| `assessment` | `/workspace` | infinite loop |
| `poc` | `/workspace/poc` | ok |
| `integration` | `/workspace` | infinite loop |
| `customer-success` | `/workspace` | infinite loop |
| *(unrecognised)* | `/workspace` | infinite loop |

Reproduced against the production build:

```
HTTP/1.1 307 Temporary Redirect    location: /workspace
HTTP/1.1 307 Temporary Redirect    location: /workspace
... (curl exit 47 = too many redirects)
```

That is exactly Chrome's `ERR_TOO_MANY_REDIRECTS`.

## Why it stayed hidden for two version generations

Two things had to be true to reach that branch: the request path must be exactly
`/workspace`, and a client-JWT cookie must be present. **Nobody could obtain that cookie
until outbound email started working**, so the first successful sign-in was also the first
request that had ever taken this code path.

The origin is v5.0 Phase 3, which retired the workspace sub-routes and made `/workspace`
itself the thread. `STATE_ROUTE`'s values were rewritten to match — correctly — but the
redirect that consumed them was left unconditional, so it began pointing at its own source.

It also explains the exact symptom: signing in bounced you to `/workspace`, which then
looped. The sign-in redirect was fine; its destination was not.

## The fix

Redirect only when the destination actually differs from the current path, with the
trailing slash normalised. Same file, no behaviour change to anything else.

## Verification

`tsc` 0 errors · `next build` 116 routes · `eslint` 52 errors / 3 warnings — all identical
to baseline.

Ten HTTP probes against the built server, `itrix_client_at=fake` standing in for a session:

| # | case | before | after |
|---|---|---|---|
| 1 | signed in, no hint | loop | `200`, 0 redirects |
| 2 | signed in, `hint=poc` | ok | `200` → `/workspace/poc`, 1 redirect |
| 3 | signed in, unrecognised hint | loop | `200`, 0 redirects |
| 4 | signed in, `/workspace/` | loop | `200` → `/workspace`, 1 redirect |
| 5 | **not** signed in | — | `200` → `/sign-in?next=%2Fworkspace` |
| 6 | signed in on `/sign-in` | loop | `200` → `/workspace` |
| 7 | signed in on `/sign-up` | loop | `200` → `/workspace` |
| 8 | signed in on `/verify-email` | — | `200`, no bounce |
| 9 | `/review` with no thread | — | `200` → `/` |
| 10 | signed in on `/workspace/poc` | — | `200`, 0 redirects |

Rows 5–10 are the regression checks: the auth guard, the signed-in bounces, the deliberate
`/verify-email` exemption and the `/review` redirect all still behave as specified.

To re-run them yourself after `npm run build`:

```bash
npx next start -p 3000 &
curl -s -o /dev/null -w "%{http_code} %{num_redirects} %{url_effective}\n" \
  -L --max-redirs 10 -b "itrix_client_at=fake" http://127.0.0.1:3000/workspace
```

Expect `200 0 http://127.0.0.1:3000/workspace`.

## After deploying

Clear cookies for `itrix-web-production.up.railway.app` before retrying — Chrome caches
307 chains, and a stale one will look like the bug is still present.

## Then commit

```powershell
git add .gitignore src/middleware.ts
git commit -m "fix(surface1): stop /workspace redirecting to itself" -m "The bare-/workspace convenience redirect was unconditional, and every
STATE_ROUTE value except poc - plus the fallback - resolves to /workspace.
So it redirected /workspace to /workspace: a 307 loop ending in
ERR_TOO_MANY_REDIRECTS on the first successful sign-in.

Latent since v5.0 Phase 3 collapsed the workspace sub-routes. Reaching the
branch needs a client-JWT cookie, and nobody could get one until outbound
email worked.

Now redirects only when the destination differs. Verified with 10 HTTP
probes covering the auth guard, both signed-in bounces, the /verify-email
exemption and /review."
git push
```
